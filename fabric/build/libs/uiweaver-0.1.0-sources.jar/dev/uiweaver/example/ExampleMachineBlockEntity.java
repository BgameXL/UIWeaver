package dev.uiweaver.example;

import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;

public class ExampleMachineBlockEntity extends class_2586 {

    private long energy = 0;
    private long maxEnergy = 10000;
    private boolean working = false;

    public ExampleMachineBlockEntity(class_2591<?> type, class_2338 pos,
                                     net.minecraft.class_2680 state) {
        super(type, pos, state);
    }

    public long getEnergy() { return energy; }
    public long getMaxEnergy() { return maxEnergy; }
    public boolean isWorking() { return working; }

    public void start() { working = true; }
    public void stop() { working = false; }
}