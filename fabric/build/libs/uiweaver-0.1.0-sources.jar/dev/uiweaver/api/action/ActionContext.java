package dev.uiweaver.api.action;

import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_3222;

public interface ActionContext {

    class_3222 player();

    String actionId();

    class_2487 payload();

    <T extends class_2586> T blockEntity(Class<T> type);

    boolean hasBlockEntity();
}