package dev.uiweaver.api.slot;

import java.util.function.Supplier;
import net.minecraft.class_1263;

public class SlotBindingDeclaration {

    private final String name;
    private final Supplier<class_1263> source;

    private SlotBindingDeclaration(String name, Supplier<class_1263> source) {
        this.name = name;
        this.source = source;
    }

    public static SlotBindingDeclaration of(String name, Supplier<class_1263> source) {
        return new SlotBindingDeclaration(name, source);
    }

    public String getName() { return name; }
    public Supplier<class_1263> getSource() { return source; }
}