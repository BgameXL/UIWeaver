package dev.uiweaver.api.context;

import net.minecraft.class_1268;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public sealed interface UIContextPayload
        permits UIContextPayload.None, UIContextPayload.BlockContext, UIContextPayload.ItemContext {

    record None() implements UIContextPayload {}

    record BlockContext(
            class_5321<class_1937> dimension,
            class_2338 pos,
            Class<?> blockEntityClass,
            int maxDistance
    ) implements UIContextPayload {

        public BlockContext(class_5321<class_1937> dimension, class_2338 pos, Class<?> blockEntityClass) {
            this(dimension, pos, blockEntityClass, 8);
        }

        public void encode(class_2540 buf) {
            buf.method_10812(dimension.method_29177());
            buf.method_10807(pos);
            buf.method_10814(blockEntityClass.getName());
            buf.writeInt(maxDistance);
        }

        public static BlockContext decode(class_2540 buf) {
            class_5321<class_1937> dim = class_5321.method_29179(class_7924.field_41223, buf.method_10810());
            class_2338 pos = buf.method_10811();
            String className = buf.method_19772();
            int dist = buf.readInt();
            try {
                return new BlockContext(dim, pos, Class.forName(className), dist);
            } catch (ClassNotFoundException e) {
                throw new IllegalStateException("Unknown BlockEntity class in UIContextPayload: " + className);
            }
        }
    }

    record ItemContext(class_1268 hand) implements UIContextPayload {

        public void encode(class_2540 buf) {
            buf.method_10817(hand);
        }

        public static ItemContext decode(class_2540 buf) {
            return new ItemContext(buf.method_10818(class_1268.class));
        }
    }

    UIContextPayload NONE = new None();

    static UIContextPayload forBlock(class_5321<class_1937> dimension, class_2338 pos, Class<?> blockEntityClass) {
        return new BlockContext(dimension, pos, blockEntityClass);
    }

    static UIContextPayload forBlock(class_5321<class_1937> dimension, class_2338 pos, Class<?> blockEntityClass, int maxDistance) {
        return new BlockContext(dimension, pos, blockEntityClass, maxDistance);
    }

    static UIContextPayload forItem(class_1268 hand) {
        return new ItemContext(hand);
    }

    static void encode(UIContextPayload payload, class_2540 buf) {
        if (payload instanceof BlockContext bc) {
            buf.writeByte(1);
            bc.encode(buf);
        } else if (payload instanceof ItemContext ic) {
            buf.writeByte(2);
            ic.encode(buf);
        } else {
            buf.writeByte(0);
        }
    }

    static UIContextPayload decode(class_2540 buf) {
        int type = buf.readByte();
        if (type == 1) return BlockContext.decode(buf);
        if (type == 2) return ItemContext.decode(buf);
        return NONE;
    }
}