package dev.uiweaver.api.component;

import net.minecraft.class_2561;

public class LabelBuilder extends ComponentBuilder<LabelBuilder> {

    private class_2561 text;
    private int maxWidth = Integer.MAX_VALUE;
    private boolean ellipsis = false;

    public LabelBuilder(class_2561 text) { this.text = text; }

    public LabelBuilder text(class_2561 text) { this.text = text; return this; }
    public LabelBuilder maxWidth(int w) { this.maxWidth = w; return this; }
    public LabelBuilder ellipsis() { this.ellipsis = true; return this; }

    @Override
    public LabelComponent build() {
        return new LabelComponent(id, visible, enabled, preferredSize, text, maxWidth, ellipsis);
    }
}