package dev.uiweaver.api.component;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;

public class DropdownBuilder extends ComponentBuilder<DropdownBuilder> {

    private final List<class_2561> options = new ArrayList<>();
    private int selectedIndex = 0;
    private String actionId   = null;

    public DropdownBuilder option(String label)      { options.add(class_2561.method_43470(label)); return this; }
    public DropdownBuilder option(class_2561 label)   { options.add(label);                    return this; }
    public DropdownBuilder options(List<String> list){ list.forEach(s -> options.add(class_2561.method_43470(s))); return this; }
    public DropdownBuilder selected(int index)       { this.selectedIndex = index;             return this; }
    public DropdownBuilder action(String actionId)   { this.actionId = actionId;               return this; }

    @Override
    public DropdownComponent build() {
        return applyTooltip(new DropdownComponent(id, visible, enabled, preferredSize,
                options, selectedIndex, actionId));
    }
}