package dev.uiweaver.api.component;

import net.minecraft.class_2561;

public class CheckboxBuilder extends ComponentBuilder<CheckboxBuilder> {

    private final class_2561 label;
    private boolean checked   = false;
    private String actionId   = null;

    public CheckboxBuilder(class_2561 label) { this.label = label; }
    public CheckboxBuilder(String label)    { this(class_2561.method_43470(label)); }

    public CheckboxBuilder checked(boolean v)    { this.checked  = v;        return this; }
    public CheckboxBuilder action(String action) { this.actionId = action;   return this; }

    @Override
    public CheckboxComponent build() {
        return applyTooltip(new CheckboxComponent(id, visible, enabled, preferredSize,
                label, checked, actionId));
    }
}