package dev.uiweaver.api.component;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;

public class TabsBuilder extends ComponentBuilder<TabsBuilder> {

    private final List<class_2561> labels   = new ArrayList<>();
    private final List<UIComponent> contents = new ArrayList<>();

    public TabsBuilder tab(String label, ComponentBuilder<?> content) {
        return tab(class_2561.method_43470(label), content.build());
    }

    public TabsBuilder tab(String label, UIComponent content) {
        return tab(class_2561.method_43470(label), content);
    }

    public TabsBuilder tab(class_2561 label, UIComponent content) {
        labels.add(label);
        contents.add(content);
        return this;
    }

    @Override
    public TabsComponent build() {
        if (labels.isEmpty()) throw new IllegalStateException("TabsBuilder requires at least one tab");
        return new TabsComponent(id, visible, enabled, preferredSize, labels, contents);
    }
}