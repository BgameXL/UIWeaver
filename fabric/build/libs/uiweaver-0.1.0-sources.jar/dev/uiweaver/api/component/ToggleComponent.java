package dev.uiweaver.api.component;

import dev.uiweaver.api.layout.Size;
import net.minecraft.class_2561;

public class ToggleComponent extends AbstractComponent implements Measurable {

    private static final int HEIGHT   = 14;
    private static final int MIN_WIDTH = 36;

    private boolean on;
    private final class_2561 labelOn;
    private final class_2561 labelOff;
    private final String actionId;

    public ToggleComponent(String id, boolean visible, boolean enabled, Size preferredSize,
                           class_2561 labelOn, class_2561 labelOff, boolean on, String actionId) {
        super(id, visible, enabled, preferredSize);
        this.labelOn  = labelOn;
        this.labelOff = labelOff;
        this.on       = on;
        this.actionId = actionId;
    }

    @Override public ComponentType getType() { return ComponentType.TOGGLE; }

    @Override
    public Size measure(int availableWidth, int availableHeight) {
        int textW = Math.max(MeasureProvider.textWidth(labelOn.getString()),
                             MeasureProvider.textWidth(labelOff.getString()));
        return Size.fixed(Math.max(MIN_WIDTH, textW + 16), HEIGHT);
    }

    public void toggle()           { this.on = !this.on; }
    public boolean isOn()          { return on; }
    public void setOn(boolean v)   { this.on = v; }
    public class_2561 getLabelOn()  { return labelOn; }
    public class_2561 getLabelOff() { return labelOff; }
    public class_2561 getActiveLabel() { return on ? labelOn : labelOff; }
    public String getActionId()    { return actionId; }
}