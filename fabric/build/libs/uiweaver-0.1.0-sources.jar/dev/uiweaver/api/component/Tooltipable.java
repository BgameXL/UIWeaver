package dev.uiweaver.api.component;

import java.util.List;
import net.minecraft.class_2561;

public interface Tooltipable {

    List<class_2561> getTooltip();
}