package dev.uiweaver.api.component;

import net.minecraft.class_2561;

public class ToggleBuilder extends ComponentBuilder<ToggleBuilder> {

    private class_2561 labelOn  = class_2561.method_43470("ON");
    private class_2561 labelOff = class_2561.method_43470("OFF");
    private boolean on         = false;
    private String actionId    = null;

    public ToggleBuilder labels(String on, String off) {
        this.labelOn  = class_2561.method_43470(on);
        this.labelOff = class_2561.method_43470(off);
        return this;
    }

    public ToggleBuilder labels(class_2561 on, class_2561 off) {
        this.labelOn  = on;
        this.labelOff = off;
        return this;
    }

    public ToggleBuilder on(boolean v)           { this.on       = v;      return this; }
    public ToggleBuilder action(String actionId) { this.actionId = actionId; return this; }

    @Override
    public ToggleComponent build() {
        return applyTooltip(new ToggleComponent(id, visible, enabled, preferredSize,
                labelOn, labelOff, on, actionId));
    }
}