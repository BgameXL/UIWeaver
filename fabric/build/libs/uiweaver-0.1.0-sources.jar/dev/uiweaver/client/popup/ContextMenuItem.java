package dev.uiweaver.client.popup;

import net.minecraft.class_2561;

public class ContextMenuItem {

    public static final ContextMenuItem SEPARATOR = new ContextMenuItem(class_2561.method_43470("---"), null, true);

    private final class_2561 label;
    private final Runnable action;
    private final boolean separator;
    private boolean enabled = true;

    public ContextMenuItem(class_2561 label, Runnable action) {
        this(label, action, false);
    }

    public ContextMenuItem(class_2561 label, Runnable action, boolean separator) {
        this.label     = label;
        this.action    = action;
        this.separator = separator;
    }

    public static ContextMenuItem of(String label, Runnable action) {
        return new ContextMenuItem(class_2561.method_43470(label), action);
    }

    public static ContextMenuItem of(class_2561 label, Runnable action) {
        return new ContextMenuItem(label, action);
    }

    public static ContextMenuItem separator() { return SEPARATOR; }

    public ContextMenuItem disabled() { this.enabled = false; return this; }

    public class_2561 getLabel()  { return label; }
    public Runnable getAction()  { return action; }
    public boolean isSeparator() { return separator; }
    public boolean isEnabled()   { return enabled; }
}