package dev.uiweaver.runtime.slot;

import dev.uiweaver.api.slot.SlotDescriptor;
import net.minecraft.class_1263;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

public class FilteredSlot extends class_1735 {

    private final SlotDescriptor descriptor;

    public FilteredSlot(class_1263 container, SlotDescriptor descriptor) {
        super(container, descriptor.getIndex(), descriptor.getX(), descriptor.getY());
        this.descriptor = descriptor;
    }

    @Override
    public boolean method_7680(class_1799 stack) {
        if (descriptor.isOutput() || descriptor.isLocked()) return false;
        if (descriptor.isGhost()) return true;
        return descriptor.getFilter().test(stack);
    }

    @Override
    public int method_7675() {
        return descriptor.getMaxStackSize();
    }

    @Override
    public boolean method_7674(net.minecraft.class_1657 player) {
        return !descriptor.isLocked();
    }

    public SlotDescriptor getDescriptor() {
        return descriptor;
    }
}