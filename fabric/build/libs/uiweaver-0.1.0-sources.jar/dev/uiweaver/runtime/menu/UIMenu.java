package dev.uiweaver.runtime.menu;

import dev.uiweaver.api.component.SlotGridComponent;
import dev.uiweaver.api.component.UIComponent;
import dev.uiweaver.api.context.UIContextPayload;
import dev.uiweaver.api.slot.SlotBindingDeclaration;
import dev.uiweaver.api.slot.SlotDescriptor;
import dev.uiweaver.api.spec.UIScreenSpec;
import dev.uiweaver.runtime.action.ActionDispatcher;
import dev.uiweaver.runtime.context.ContextValidator;
import dev.uiweaver.runtime.lifecycle.SessionManager;
import dev.uiweaver.runtime.lifecycle.UIScreenSession;
import dev.uiweaver.runtime.network.ActionPacket;
import dev.uiweaver.runtime.network.NetworkChannel;
import dev.uiweaver.runtime.network.SyncPacket;
import dev.uiweaver.runtime.slot.FilteredSlot;
import dev.uiweaver.runtime.sync.SyncManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import net.minecraft.class_3917;

public class UIMenu extends class_1703 {

    private static final Logger LOGGER = LoggerFactory.getLogger(UIMenu.class);

    private final UIScreenSpec spec;
    private final SyncManager syncManager;
    private final ActionDispatcher dispatcher;
    private final NetworkChannel channel;
    private final class_1661 playerInventory;
    private final int machineSlotCount;
    private UIScreenSession session;
    private int clientSessionId = -1;

    public UIMenu(class_3917<?> type, int containerId, class_1661 playerInventory,
                  UIScreenSpec spec, NetworkChannel channel) {
        super(type, containerId);
        this.playerInventory = playerInventory;
        this.spec            = spec;
        this.channel         = channel;
        this.syncManager     = new SyncManager(spec.getSyncs());
        this.dispatcher      = new ActionDispatcher(spec.getScreenId(), spec.getActions(), spec.getContextPayload());

        Map<String, class_1263> resolved = resolveSlotBindings(spec);
        registerSlotsFromSpec(spec.getRoot(), resolved);
        this.machineSlotCount = field_7761.size();
        addPlayerInventorySlots(playerInventory);
    }

    public void onOpened(class_3222 player) {
        this.session = SessionManager.open(player, new UIScreenSession(player, spec));
        syncManager.forceFullSync();
    }

    public void setClientSessionId(int id) { this.clientSessionId = id; }
    public int getClientSessionId() { return clientSessionId; }

    public int getSessionId() {
        return session != null ? session.getSessionId() : -1;
    }

    private Map<String, class_1263> resolveSlotBindings(UIScreenSpec spec) {
        Map<String, class_1263> resolved = new HashMap<>();
        for (SlotBindingDeclaration decl : spec.getSlotBindings()) {
            try {
                class_1263 container = decl.getSource().get();
                if (container != null) resolved.put(decl.getName(), container);
                else LOGGER.warn("[UIWeaver] Slot binding '{}' returned null", decl.getName());
            } catch (Exception e) {
                LOGGER.error("[UIWeaver] Failed to resolve slot binding '{}'", decl.getName(), e);
            }
        }
        return resolved;
    }

    private void registerSlotsFromSpec(UIComponent component, Map<String, class_1263> containers) {
        if (component instanceof SlotGridComponent grid) {
            class_1263 container;
            if (grid.hasBoundContainer()) {
                container = containers.get(grid.getBindingName());
                if (container == null) {
                    LOGGER.warn("[UIWeaver] SlotGrid '{}' bound to '{}' but no match — using SimpleContainer",
                            grid.getId(), grid.getBindingName());
                    container = new class_1277(grid.getSlots().size());
                }
            } else {
                container = new class_1277(grid.getSlots().size());
            }
            for (SlotDescriptor descriptor : grid.getSlots()) {
                method_7621(new FilteredSlot(container, descriptor));
            }
        }
        for (UIComponent child : component.getChildren()) {
            registerSlotsFromSpec(child, containers);
        }
    }

    private void addPlayerInventorySlots(class_1661 inventory) {
        for (int row = 0; row < 3; row++)
            for (int col = 0; col < 9; col++)
                method_7621(new class_1735(inventory, col + row * 9 + 9, 0, 0));
        for (int col = 0; col < 9; col++)
            method_7621(new class_1735(inventory, col, 0, 0));
    }

    @Override
    public void method_7623() {
        super.method_7623();
        if (!(playerInventory.field_7546 instanceof class_3222 serverPlayer)) return;
        syncManager.tick();
        if (syncManager.hasPending()) {
            channel.sendToClient(serverPlayer, new SyncPacket(spec.getScreenId(), syncManager.drainPending()));
        }
    }

    @Override
    public void method_7595(class_1657 player) {
        super.method_7595(player);
        if (player instanceof class_3222 sp) SessionManager.close(sp);
    }

    @Override
    public class_1799 method_7601(class_1657 player, int index) {
        class_1735 slot = field_7761.get(index);
        if (!slot.method_7681()) return class_1799.field_8037;
        class_1799 stack = slot.method_7677();
        class_1799 original = stack.method_7972();
        if (index < machineSlotCount) {
            if (!method_7616(stack, machineSlotCount, field_7761.size(), true)) return class_1799.field_8037;
        } else {
            if (!method_7616(stack, 0, machineSlotCount, false)) return class_1799.field_8037;
        }
        if (stack.method_7960()) slot.method_7673(class_1799.field_8037);
        else slot.method_7668();
        if (stack.method_7947() == original.method_7947()) return class_1799.field_8037;
        return original;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        if (!(player instanceof class_3222 sp)) return true;
        UIContextPayload payload = spec.getContextPayload();
        if (payload instanceof UIContextPayload.BlockContext) {
            return ContextValidator.validate(sp, payload) == ContextValidator.Result.OK;
        }
        return true;
    }

    public void handleAction(ActionPacket packet, class_3222 player) {
        dispatcher.dispatch(packet, player);
    }

    public void forceFullSync() { syncManager.forceFullSync(); }

    public UIScreenSpec getSpec() { return spec; }
}