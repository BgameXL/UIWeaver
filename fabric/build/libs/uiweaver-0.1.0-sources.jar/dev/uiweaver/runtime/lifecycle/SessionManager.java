package dev.uiweaver.runtime.lifecycle;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_3222;

public class SessionManager {

    private static final ConcurrentHashMap<UUID, UIScreenSession> ACTIVE = new ConcurrentHashMap<>();

    public static UIScreenSession open(class_3222 player, UIScreenSession session) {
        ACTIVE.put(player.method_5667(), session);
        return session;
    }

    public static void close(class_3222 player) {
        ACTIVE.remove(player.method_5667());
    }

    public static UIScreenSession get(class_3222 player) {
        return ACTIVE.get(player.method_5667());
    }

    public static boolean isValid(class_3222 player, int sessionId) {
        UIScreenSession session = ACTIVE.get(player.method_5667());
        return session != null && session.getSessionId() == sessionId;
    }
}