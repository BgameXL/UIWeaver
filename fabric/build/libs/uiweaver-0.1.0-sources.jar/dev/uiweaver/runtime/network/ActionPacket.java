package dev.uiweaver.runtime.network;

import net.minecraft.class_2487;
import net.minecraft.class_2540;

public class ActionPacket {

    public static final String ID = "uiweaver:action";

    private final int sessionId;
    private final String screenId;
    private final String actionId;
    private final class_2487 payload;

    public ActionPacket(int sessionId, String screenId, String actionId, class_2487 payload) {
        this.sessionId = sessionId;
        this.screenId  = screenId;
        this.actionId  = actionId;
        this.payload   = payload != null ? payload : new class_2487();
    }

    public ActionPacket(int sessionId, String screenId, String actionId) {
        this(sessionId, screenId, actionId, new class_2487());
    }

    public static ActionPacket decode(class_2540 buf) {
        int sessionId   = buf.readInt();
        String screenId = buf.method_19772();
        String actionId = buf.method_19772();
        class_2487 payload = buf.method_10798();
        return new ActionPacket(sessionId, screenId, actionId, payload);
    }

    public void encode(class_2540 buf) {
        buf.writeInt(sessionId);
        buf.method_10814(screenId);
        buf.method_10814(actionId);
        buf.method_10794(payload);
    }

    public int getSessionId()       { return sessionId; }
    public String getScreenId()     { return screenId; }
    public String getActionId()     { return actionId; }
    public class_2487 getPayload() { return payload; }
}