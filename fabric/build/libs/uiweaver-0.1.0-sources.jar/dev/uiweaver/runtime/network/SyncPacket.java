package dev.uiweaver.runtime.network;

import dev.uiweaver.api.sync.SyncType;
import dev.uiweaver.runtime.sync.SyncEntry;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2487;
import net.minecraft.class_2540;

public class SyncPacket {

    public static final String ID = "uiweaver:sync";

    private final String screenId;
    private final List<SyncEntry> entries;

    public SyncPacket(String screenId, List<SyncEntry> entries) {
        this.screenId = screenId;
        this.entries  = entries;
    }

    public static SyncPacket decode(class_2540 buf) {
        String screenId = buf.method_19772();
        int count = buf.method_10816();
        List<SyncEntry> entries = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            String key   = buf.method_19772();
            SyncType type = buf.method_10818(SyncType.class);
            Object value = switch (type) {
                case INT         -> buf.readInt();
                case LONG        -> buf.readLong();
                case BOOLEAN     -> buf.readBoolean();
                case FLOAT       -> buf.readFloat();
                case STRING      -> buf.method_19772();
                case STRING_LIST -> {
                    int len = buf.method_10816();
                    List<String> list = new ArrayList<>(len);
                    for (int j = 0; j < len; j++) list.add(buf.method_19772());
                    yield List.copyOf(list);
                }
                case NBT_LIST -> {
                    int len = buf.method_10816();
                    List<class_2487> list = new ArrayList<>(len);
                    for (int j = 0; j < len; j++) list.add(buf.method_10798());
                    yield List.copyOf(list);
                }
            };
            entries.add(new SyncEntry(key, type, value));
        }
        return new SyncPacket(screenId, entries);
    }

    public void encode(class_2540 buf) {
        buf.method_10814(screenId);
        buf.method_10804(entries.size());
        for (SyncEntry e : entries) {
            buf.method_10814(e.key());
            buf.method_10817(e.type());
            switch (e.type()) {
                case INT     -> buf.writeInt(e.asInt());
                case LONG    -> buf.writeLong(e.asLong());
                case BOOLEAN -> buf.writeBoolean(e.asBoolean());
                case FLOAT   -> buf.writeFloat(e.asFloat());
                case STRING  -> buf.method_10814(e.asString());
                case STRING_LIST -> {
                    List<String> list = e.asStringList();
                    buf.method_10804(list.size());
                    list.forEach(buf::method_10814);
                }
                case NBT_LIST -> {
                    List<class_2487> list = e.asNbtList();
                    buf.method_10804(list.size());
                    list.forEach(buf::method_10794);
                }
            }
        }
    }

    public String getScreenId()       { return screenId; }
    public List<SyncEntry> getEntries() { return entries; }
}