package dev.uiweaver.runtime.network;

import net.minecraft.class_3222;

public interface NetworkChannel {

    void sendToClient(class_3222 player, SyncPacket packet);

    void registerServerHandler(String packetId, ServerPacketHandler handler);

    @FunctionalInterface
    interface ServerPacketHandler {
        void handle(ActionPacket packet, class_3222 sender);
    }
}