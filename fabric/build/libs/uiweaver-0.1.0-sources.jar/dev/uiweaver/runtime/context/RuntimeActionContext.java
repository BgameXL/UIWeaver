package dev.uiweaver.runtime.context;

import dev.uiweaver.api.action.ActionContext;
import dev.uiweaver.api.context.UIContextPayload;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_3222;

public class RuntimeActionContext implements ActionContext {

    private final class_3222 player;
    private final UIContextPayload payload;
    private final String actionId;
    private final class_2487 data;

    public RuntimeActionContext(class_3222 player, UIContextPayload payload,
                                String actionId, class_2487 data) {
        this.player   = player;
        this.payload  = payload;
        this.actionId = actionId;
        this.data     = data != null ? data : new class_2487();
    }

    @Override public class_3222 player()    { return player; }
    @Override public String actionId()        { return actionId; }
    @Override public class_2487 payload()    { return data; }

    @Override
    @SuppressWarnings("unchecked")
    public <T extends class_2586> T blockEntity(Class<T> type) {
        if (!(payload instanceof UIContextPayload.BlockContext bc))
            throw new IllegalStateException("Context is not a BlockContext");
        class_2586 be = player.method_51469().method_8321(bc.pos());
        if (be == null || !type.isInstance(be))
            throw new IllegalStateException("BlockEntity at " + bc.pos() + " is not " + type.getSimpleName());
        return (T) be;
    }

    @Override
    public boolean hasBlockEntity() {
        if (!(payload instanceof UIContextPayload.BlockContext bc)) return false;
        return player.method_51469().method_8321(bc.pos()) != null;
    }
}