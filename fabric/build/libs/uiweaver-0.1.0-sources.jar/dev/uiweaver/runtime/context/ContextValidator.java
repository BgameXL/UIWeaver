package dev.uiweaver.runtime.context;

import dev.uiweaver.api.context.UIContextPayload;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_3222;

public class ContextValidator {

    public enum Result {
        OK,
        TOO_FAR,
        BLOCK_ENTITY_MISSING,
        BLOCK_ENTITY_WRONG_TYPE,
        WRONG_DIMENSION,
        ITEM_MISSING
    }

    public static Result validate(class_3222 player, UIContextPayload payload) {
        if (payload instanceof UIContextPayload.BlockContext bc) return validateBlock(player, bc);
        if (payload instanceof UIContextPayload.ItemContext ic) return validateItem(player, ic);
        return Result.OK;
    }

    private static Result validateBlock(class_3222 player, UIContextPayload.BlockContext bc) {
        if (!player.method_51469().method_27983().equals(bc.dimension())) return Result.WRONG_DIMENSION;

        class_2338 pos = bc.pos();
        double distSqr = player.method_5649(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5);
        int max = bc.maxDistance();
        if (distSqr > (double) max * max) return Result.TOO_FAR;

        class_2586 be = player.method_51469().method_8321(pos);
        if (be == null) return Result.BLOCK_ENTITY_MISSING;
        if (!bc.blockEntityClass().isInstance(be)) return Result.BLOCK_ENTITY_WRONG_TYPE;

        return Result.OK;
    }

    private static Result validateItem(class_3222 player, UIContextPayload.ItemContext ic) {
        if (player.method_5998(ic.hand()).method_7960()) return Result.ITEM_MISSING;
        return Result.OK;
    }
}