package dev.uiweaver.fabric.client.render;

import dev.uiweaver.client.theme.UITheme;
import net.minecraft.class_2960;
import net.minecraft.class_332;

public class UIBackground {

    private static final class_2960 DEFAULT_TEXTURE =
            new class_2960("uiweaver", "textures/gui/panel.png");

    private static final int DEFAULT_TEXTURE_W = 256;
    private static final int DEFAULT_TEXTURE_H = 256;

    public static void render(class_332 graphics, UITheme theme,
                               int x, int y, int width, int height) {
        class_2960 texture = theme.getPanelTexture();

        if (texture != null) {
            renderTextured(graphics, texture, x, y, width, height);
        } else {
            renderSolid(graphics, theme, x, y, width, height);
        }
    }

    private static void renderTextured(class_332 graphics, class_2960 texture,
                                        int x, int y, int width, int height) {
        graphics.method_25290(texture, x, y, 0, 0, width, height, DEFAULT_TEXTURE_W, DEFAULT_TEXTURE_H);
    }

    private static void renderSolid(class_332 graphics, UITheme theme,
                                     int x, int y, int width, int height) {
        graphics.method_25294(x + 2, y + 2, x + width + 2, y + height + 2, 0x55000000);
        graphics.method_25294(x, y, x + width, y + height, theme.getBackgroundColor());
        graphics.method_49601(x, y, width, height, theme.getBorderColor());
        graphics.method_25294(x + 1, y + 1, x + width - 1, y + 2, 0x22FFFFFF);
        graphics.method_25294(x + 1, y + 1, x + 2, y + height - 1, 0x22FFFFFF);
    }
}