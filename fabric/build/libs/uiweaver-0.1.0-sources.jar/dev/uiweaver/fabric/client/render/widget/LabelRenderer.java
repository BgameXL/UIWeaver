package dev.uiweaver.fabric.client.render.widget;

import dev.uiweaver.api.component.LabelComponent;
import dev.uiweaver.api.layout.Bounds;
import dev.uiweaver.api.view.UIViewModel;
import dev.uiweaver.client.render.RenderLayer;
import dev.uiweaver.fabric.client.render.FabricWidgetRenderer;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import dev.uiweaver.client.theme.UITheme;

public class LabelRenderer implements FabricWidgetRenderer<LabelComponent> {

    @Override
    public void render(class_332 graphics, LabelComponent component, UIViewModel viewModel,
                       UITheme theme, int mouseX, int mouseY, RenderLayer layer) {
        if (layer != RenderLayer.FOREGROUND) return;

        Bounds b = component.getBounds();
        if (b == null) return;

        class_327 font = class_310.method_1551().field_1772;
        String text = font.method_27523(component.getText().getString(),
                component.isEllipsis() ? component.getMaxWidth() : Integer.MAX_VALUE);

        graphics.method_51433(font, text, b.x(), b.y(), theme.getTextColor(), false);
    }
}