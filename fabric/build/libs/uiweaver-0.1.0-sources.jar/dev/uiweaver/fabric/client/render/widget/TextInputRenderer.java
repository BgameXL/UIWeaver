package dev.uiweaver.fabric.client.render.widget;

import dev.uiweaver.api.component.TextInputComponent;
import dev.uiweaver.api.layout.Bounds;
import dev.uiweaver.api.view.UIViewModel;
import dev.uiweaver.client.render.RenderLayer;
import dev.uiweaver.fabric.client.render.FabricWidgetRenderer;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import dev.uiweaver.client.theme.UITheme;

public class TextInputRenderer implements FabricWidgetRenderer<TextInputComponent> {

    private static final int PLACEHOLDER_COLOR = 0xFF666666;
    private static final int CURSOR_COLOR = 0xFFCCCCCC;
    private static final int PADDING = 3;

    @Override
    public void render(class_332 graphics, TextInputComponent component, UIViewModel viewModel,
                       UITheme theme, int mouseX, int mouseY, RenderLayer layer) {
        if (layer != RenderLayer.FOREGROUND) return;

        Bounds b = component.getBounds();
        if (b == null) return;

        graphics.method_25294(b.x(), b.y(), b.right(), b.bottom(), theme.getFluidBarBackgroundColor());
        graphics.method_49601(b.x(), b.y(), b.width(), b.height(), theme.getBorderColor());

        class_327 font = class_310.method_1551().field_1772;
        int textX = b.x() + PADDING;
        int textY = b.y() + (b.height() - font.field_2000) / 2;

        String value = component.getValue();
        if (value.isEmpty()) {
            graphics.method_51433(font, component.getPlaceholder(), textX, textY, PLACEHOLDER_COLOR, false);
        } else {
            graphics.method_51433(font, value, textX, textY, theme.getTextColor(), false);

            int cursorX = textX + font.method_1727(value);
            if (cursorX < b.right() - PADDING && (System.currentTimeMillis() / 500) % 2 == 0) {
                graphics.method_25294(cursorX, textY, cursorX + 1, textY + font.field_2000, CURSOR_COLOR);
            }
        }
    }
}