package dev.uiweaver.fabric.client.render;

import dev.uiweaver.api.component.ComponentType;
import dev.uiweaver.api.component.UIComponent;
import dev.uiweaver.client.render.WidgetRendererRegistry;
import net.minecraft.class_332;

public class FabricWidgetRendererRegistry extends WidgetRendererRegistry<class_332> {

    private static final FabricWidgetRendererRegistry INSTANCE = new FabricWidgetRendererRegistry();

    private FabricWidgetRendererRegistry() {}

    public static FabricWidgetRendererRegistry instance() {
        return INSTANCE;
    }

    public <T extends UIComponent> void register(ComponentType type, FabricWidgetRenderer<T> renderer) {
        super.register(type, renderer);
    }

    @SuppressWarnings("unchecked")
    public <T extends UIComponent> FabricWidgetRenderer<T> get(ComponentType type) {
        return (FabricWidgetRenderer<T>) super.get(type);
    }
}