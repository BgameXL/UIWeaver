package dev.uiweaver.fabric.client.screen;

import dev.uiweaver.client.screen.ClientNetworkBridge;
import dev.uiweaver.runtime.menu.UIMenu;
import dev.uiweaver.runtime.network.ActionPacket;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class FabricScreenActionSender {

    public static void sendAction(String screenId, String actionId) {
        sendAction(screenId, actionId, new class_2487());
    }

    public static void sendAction(String screenId, String actionId, class_2487 payload) {
        int sessionId = -1;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null && mc.field_1724.field_7512 instanceof UIMenu menu) {
            sessionId = menu.getClientSessionId();
        }
        ClientNetworkBridge.sendToServer(new ActionPacket(sessionId, screenId, actionId, payload));
    }
}
