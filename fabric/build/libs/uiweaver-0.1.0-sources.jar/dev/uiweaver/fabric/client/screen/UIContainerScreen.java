package dev.uiweaver.fabric.client.screen;

import dev.uiweaver.api.spec.UIScreenSpec;
import dev.uiweaver.api.view.UIViewModel;
import dev.uiweaver.fabric.client.input.InputHandler;
import dev.uiweaver.fabric.client.render.UIRenderer;
import dev.uiweaver.runtime.menu.UIMenu;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_465;

public class UIContainerScreen extends class_465<UIMenu> {

    private final UIScreenSpec spec;
    private final UIViewModel viewModel;
    private UIRenderer renderer;
    private InputHandler inputHandler;

    public UIContainerScreen(UIMenu menu, class_1661 inventory, class_2561 title) {
        super(menu, inventory, title);
        this.spec = menu.getSpec();
        this.viewModel = new UIViewModel();
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        this.renderer = new UIRenderer(spec, viewModel);
        this.inputHandler = new InputHandler(spec, viewModel, this::sendAction);
        renderer.init(field_2776, field_2800, field_2792, field_2779);
    }

    @Override
    protected void method_2389(class_332 graphics, float partialTick, int mouseX, int mouseY) {
        renderer.renderBackground(graphics, mouseX, mouseY);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        renderer.renderForeground(graphics, mouseX, mouseY);
        method_2380(graphics, mouseX, mouseY);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (inputHandler.onMouseClicked(mouseX, mouseY, button)) return true;
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double delta) {
        if (inputHandler.onMouseScrolled(mouseX, mouseY, delta)) return true;
        return super.method_25401(mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (inputHandler.onKeyPressed(keyCode, scanCode, modifiers)) return true;
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25400(char c, int modifiers) {
        if (inputHandler.onCharTyped(c, modifiers)) return true;
        return super.method_25400(c, modifiers);
    }

    public void applySync(String key, Object value) {
        viewModel.put(key, value);
        renderer.onViewModelUpdated(key);
    }

    private void sendAction(String actionId) {
        FabricScreenActionSender.sendAction(spec.getScreenId(), actionId);
    }
}