package dev.uiweaver.fabric.client.render.widget;

import dev.uiweaver.api.component.ScrollPanelComponent;
import dev.uiweaver.api.component.UIComponent;
import dev.uiweaver.api.layout.Bounds;
import dev.uiweaver.api.view.UIViewModel;
import dev.uiweaver.client.render.RenderLayer;
import dev.uiweaver.fabric.client.render.FabricWidgetRenderer;
import dev.uiweaver.fabric.client.render.FabricWidgetRendererRegistry;
import net.minecraft.class_1041;
import net.minecraft.class_310;
import net.minecraft.class_332;
import dev.uiweaver.client.theme.UITheme;

public class ScrollPanelRenderer implements FabricWidgetRenderer<ScrollPanelComponent> {

    private static final int SCROLLBAR_WIDTH = 4;
    private static final int SCROLLBAR_COLOR = 0xFF555555;
    private static final int SCROLLBAR_THUMB = 0xFF888888;

    @Override
    public void render(class_332 graphics, ScrollPanelComponent component, UIViewModel viewModel,
                       UITheme theme, int mouseX, int mouseY, RenderLayer layer) {
        Bounds b = component.getBounds();
        if (b == null) return;

        if (layer == RenderLayer.BACKGROUND) {
            graphics.method_25294(b.x(), b.y(), b.right(), b.bottom(), theme.getFluidBarBackgroundColor());

            if (component.canScroll()) {
                renderScrollbar(graphics, component, b);
            }
        }

        if (layer == RenderLayer.FOREGROUND) {
            renderChildren(graphics, component, viewModel, theme, mouseX, mouseY, b);
        }
    }

    private void renderChildren(class_332 graphics, ScrollPanelComponent component,
                                UIViewModel viewModel, UITheme theme,
                                int mouseX, int mouseY, Bounds b) {
        int contentWidth = component.canScroll() ? b.width() - SCROLLBAR_WIDTH - 1 : b.width();

        var window = class_310.method_1551().method_22683();
        double scale = window.method_4495();
        int sx = (int) (b.x() * scale);
        int sy = (int) ((window.method_4502() - b.bottom()) * scale);
        int sw = (int) (contentWidth * scale);
        int sh = (int) (b.height() * scale);
        com.mojang.blaze3d.platform.GlStateManager._enableScissorTest();
        com.mojang.blaze3d.platform.GlStateManager._scissorBox(sx, sy, sw, sh);

        int offset = component.getScrollOffset();
        FabricWidgetRendererRegistry reg = FabricWidgetRendererRegistry.instance();

        for (UIComponent child : component.getChildren()) {
            if (!child.isVisible()) continue;
            Bounds cb = child.getBounds();
            if (cb == null) continue;

            Bounds shifted = Bounds.of(cb.x(), cb.y() - offset, cb.width(), cb.height());
            child.setBounds(shifted);

            if (shifted.bottom() > b.y() && shifted.y() < b.bottom()) {
                @SuppressWarnings("unchecked")
                FabricWidgetRenderer<UIComponent> renderer = reg.get(child.getType());
                if (renderer != null) {
                    renderer.render(graphics, child, viewModel, theme, mouseX, mouseY + offset, RenderLayer.FOREGROUND);
                }
            }

            child.setBounds(cb);
        }

        com.mojang.blaze3d.platform.GlStateManager._disableScissorTest();
    }

    private void renderScrollbar(class_332 graphics, ScrollPanelComponent component, Bounds b) {
        int trackX = b.right() - SCROLLBAR_WIDTH;
        graphics.method_25294(trackX, b.y(), b.right(), b.bottom(), SCROLLBAR_COLOR);

        float viewH = b.height();
        float contentH = component.getContentHeight();
        float thumbH = Math.max(10, viewH * viewH / contentH);
        float thumbY = b.y() + (component.getScrollOffset() / (contentH - viewH)) * (viewH - thumbH);

        graphics.method_25294(trackX, (int) thumbY, b.right(), (int) (thumbY + thumbH), SCROLLBAR_THUMB);
    }
}