package dev.uiweaver.fabric.client.render.widget;

import dev.uiweaver.api.component.EnergyBarComponent;
import dev.uiweaver.api.layout.Bounds;
import dev.uiweaver.api.view.UIViewModel;
import dev.uiweaver.client.render.RenderLayer;
import dev.uiweaver.fabric.client.render.FabricWidgetRenderer;
import dev.uiweaver.client.theme.UITheme;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5481;

public class EnergyBarRenderer implements FabricWidgetRenderer<EnergyBarComponent> {

    @Override
    public void render(class_332 graphics, EnergyBarComponent component, UIViewModel viewModel,
                       UITheme theme, int mouseX, int mouseY, RenderLayer layer) {
        Bounds b = component.getBounds();
        if (b == null) return;

        if (layer == RenderLayer.BACKGROUND) {
            graphics.method_25294(b.x(), b.y(), b.right(), b.bottom(), theme.getFluidBarBackgroundColor());
            graphics.method_49601(b.x(), b.y(), b.width(), b.height(), theme.getBorderColor());

            float fill = component.getFillFraction();
            if (fill > 0f) {
                int fillHeight = (int) ((b.height() - 2) * fill);
                int fillY = b.bottom() - 1 - fillHeight;
                graphics.method_25294(b.x() + 1, fillY, b.right() - 1, b.bottom() - 1, theme.getEnergyBarColor());
            }
        }

        if (layer == RenderLayer.TOOLTIP && b.contains(mouseX, mouseY)) {
            class_2561 text = class_2561.method_43470(component.getEnergy() + " / " + component.getMaxEnergy() + " FE");
            List<class_5481> lines = List.of(text.method_30937());
            graphics.method_51447(class_310.method_1551().field_1772, lines, mouseX, mouseY);
        }
    }
}