package dev.uiweaver.fabric.client.render.widget;

import dev.uiweaver.api.component.ButtonComponent;
import dev.uiweaver.api.layout.Bounds;
import dev.uiweaver.api.view.UIViewModel;
import dev.uiweaver.client.render.RenderLayer;
import dev.uiweaver.fabric.client.render.FabricWidgetRenderer;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import dev.uiweaver.client.theme.UITheme;

public class ButtonRenderer implements FabricWidgetRenderer<ButtonComponent> {

    @Override
    public void render(class_332 graphics, ButtonComponent component, UIViewModel viewModel,
                       UITheme theme, int mouseX, int mouseY, RenderLayer layer) {
        if (layer != RenderLayer.FOREGROUND) return;

        Bounds b = component.getBounds();
        if (b == null) return;

        boolean hovered = b.contains(mouseX, mouseY) && component.isEnabled();
        int bgColor = hovered ? theme.getButtonHoverColor() : theme.getButtonColor();

        graphics.method_25294(b.x(), b.y(), b.right(), b.bottom(), bgColor);
        graphics.method_49601(b.x(), b.y(), b.width(), b.height(), theme.getBorderColor());

        class_327 font = class_310.method_1551().field_1772;
        String text = component.getLabel().getString();
        int textX = b.x() + (b.width() - font.method_1727(text)) / 2;
        int textY = b.y() + (b.height() - font.field_2000) / 2;
        int textColor = component.isEnabled() ? theme.getTextColor() : theme.getTextColorDisabled();

        graphics.method_51433(font, text, textX, textY, textColor, false);
    }
}