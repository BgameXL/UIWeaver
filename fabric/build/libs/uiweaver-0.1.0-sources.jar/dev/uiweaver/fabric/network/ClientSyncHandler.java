package dev.uiweaver.fabric.network;

import dev.uiweaver.fabric.client.screen.UIContainerScreen;
import dev.uiweaver.runtime.network.SyncPacket;
import dev.uiweaver.runtime.sync.SyncEntry;
import net.minecraft.class_310;

public class ClientSyncHandler {

    public static void handle(SyncPacket packet) {
        var mc = class_310.method_1551();
        if (!(mc.field_1755 instanceof UIContainerScreen screen)) return;
        if (!screen.method_17577().getSpec().getScreenId().equals(packet.getScreenId())) return;

        for (var entry : packet.getEntries()) {
            screen.applySync(entry.key(), entry.value());
        }
    }
}