package dev.uiweaver.fabric.network;

import dev.uiweaver.runtime.menu.UIMenu;
import dev.uiweaver.runtime.network.ActionPacket;
import net.minecraft.class_3222;

public class ServerActionHandler {

    public static void handle(ActionPacket packet, class_3222 player) {
        if (player.field_7512 instanceof UIMenu menu) {
            menu.handleAction(packet, player);
        }
    }
}