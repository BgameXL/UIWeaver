package dev.uiweaver.fabric.registry;

import dev.uiweaver.api.UIBuilder;
import dev.uiweaver.api.UIScreen;
import dev.uiweaver.api.context.UIContextPayload;
import dev.uiweaver.api.spec.UIScreenSpec;
import dev.uiweaver.fabric.client.screen.UIContainerScreen;
import dev.uiweaver.fabric.network.FabricNetworkChannel;
import dev.uiweaver.runtime.lifecycle.SessionManager;
import dev.uiweaver.runtime.lifecycle.UIScreenSession;
import dev.uiweaver.runtime.menu.UIMenu;
import dev.uiweaver.runtime.registry.UIRegistry;
import dev.uiweaver.fabric.client.screen.UIContainerScreen;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_2378;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3917;
import net.minecraft.class_7923;

public class FabricMenuRegistry {

    public static class_3917<UIMenu> GENERIC_MENU;
    private static FabricNetworkChannel channel;

    public static void setChannel(FabricNetworkChannel ch) { channel = ch; }

    public static void register() {
        GENERIC_MENU = class_2378.method_10230(
                class_7923.field_41187,
                new class_2960("uiweaver", "generic_menu"),
                new ExtendedScreenHandlerType<>((containerId, inventory, buf) -> {
                    String screenId          = buf.method_19772();
                    int sessionId            = buf.readInt();
                    UIContextPayload payload = UIContextPayload.decode(buf);

                    UIScreen factory = UIRegistry.getFactory(screenId);
                    if (factory == null) return null;

                    UIScreenSpec spec = factory.build(UIBuilder.screen(screenId));
                    UIMenu menu = new UIMenu(GENERIC_MENU, containerId, inventory, spec, channel);
                    menu.setClientSessionId(sessionId);
                    return menu;
                })
        );
    }

    public static void registerScreen() {
        net.fabricmc.fabric.api.client.screenhandler.v1.ScreenRegistry.register(
                GENERIC_MENU,
                (net.fabricmc.fabric.api.client.screenhandler.v1.ScreenRegistry.Factory<UIMenu, UIContainerScreen>)
                        (menu, inventory, title) -> new UIContainerScreen(menu, inventory, class_2561.method_43470(menu.getSpec().getScreenId()))
        );
    }

    public static void open(class_3222 player, UIScreen screen, String screenId, UIContextPayload payload) {
        UIRegistry.registerFactory(screenId, screen);
        UIScreenSpec spec = screen.build(UIBuilder.screen(screenId));
        UIScreenSession session = new UIScreenSession(player, spec);
        SessionManager.open(player, session);

        player.method_17355(new ExtendedScreenHandlerFactory() {
            @Override public class_2561 method_5476() { return class_2561.method_43470(screenId); }

            @Override
            public UIMenu createMenu(int containerId, class_1661 inventory, class_1657 p) {
                UIMenu menu = new UIMenu(GENERIC_MENU, containerId, inventory, spec, channel);
                menu.onOpened(player);
                return menu;
            }

            @Override
            public void writeScreenOpeningData(class_3222 p, class_2540 buf) {
                buf.method_10814(screenId);
                buf.writeInt(session.getSessionId());
                UIContextPayload.encode(payload, buf);
            }
        });
    }

    public static void open(class_3222 player, String screenId, UIContextPayload payload) {
        UIScreen factory = UIRegistry.getFactory(screenId);
        if (factory == null) throw new IllegalArgumentException("No factory for screen: " + screenId);
        open(player, factory, screenId, payload);
    }

    public static void open(class_3222 player, String screenId) {
        open(player, screenId, UIContextPayload.NONE);
    }
}