package dev.uiweaver.forge.network;

import dev.uiweaver.forge.client.screen.UIContainerScreen;
import dev.uiweaver.runtime.network.SyncPacket;
import dev.uiweaver.runtime.sync.SyncEntry;
import net.minecraft.client.Minecraft;

public class ClientSyncHandler {

    public static void handle(SyncPacket packet) {
        var mc = Minecraft.m_91087_();
        if (!(mc.f_91080_ instanceof UIContainerScreen screen)) return;
        if (!screen.m_6262_().getSpec().getScreenId().equals(packet.getScreenId())) return;

        for (var entry : packet.getEntries()) {
            screen.applySync(entry.key(), entry.value());
        }
    }
}