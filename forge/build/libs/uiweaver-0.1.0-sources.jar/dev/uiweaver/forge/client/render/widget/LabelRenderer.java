package dev.uiweaver.forge.client.render.widget;

import dev.uiweaver.api.component.LabelComponent;
import dev.uiweaver.api.layout.Bounds;
import dev.uiweaver.api.view.UIViewModel;
import dev.uiweaver.client.render.RenderLayer;
import dev.uiweaver.forge.client.render.ForgeWidgetRenderer;
import dev.uiweaver.client.theme.UITheme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

public class LabelRenderer implements ForgeWidgetRenderer<LabelComponent> {

    @Override
    public void render(GuiGraphics graphics, LabelComponent component, UIViewModel viewModel,
                       UITheme theme, int mouseX, int mouseY, RenderLayer layer) {
        if (layer != RenderLayer.FOREGROUND) return;

        Bounds b = component.getBounds();
        if (b == null) return;

        Font font = Minecraft.m_91087_().f_91062_;
        String text = font.m_92834_(component.getText().getString(),
                component.isEllipsis() ? component.getMaxWidth() : Integer.MAX_VALUE);

        graphics.m_280056_(font, text, b.x(), b.y(), theme.getTextColor(), false);
    }
}