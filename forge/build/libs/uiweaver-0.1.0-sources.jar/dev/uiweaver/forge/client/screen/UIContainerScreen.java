package dev.uiweaver.forge.client.screen;

import dev.uiweaver.api.component.AbstractComponent;
import dev.uiweaver.api.layout.Size;
import dev.uiweaver.api.spec.UIScreenSpec;
import dev.uiweaver.api.view.UIViewModel;
import dev.uiweaver.client.input.FocusManager;
import dev.uiweaver.client.modal.ModalManager;
import dev.uiweaver.client.popup.PopupManager;
import dev.uiweaver.forge.client.debug.UIDebugOverlay;
import dev.uiweaver.forge.client.debug.UIInspector;
import dev.uiweaver.forge.client.input.InputHandler;
import dev.uiweaver.forge.client.popup.PopupRenderer;
import dev.uiweaver.forge.client.render.UIRenderer;
import dev.uiweaver.runtime.menu.UIMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import org.lwjgl.glfw.GLFW;

public class UIContainerScreen extends AbstractContainerScreen<UIMenu> {

    private final UIScreenSpec spec;
    private final UIViewModel viewModel;
    private UIRenderer renderer;
    private InputHandler inputHandler;
    private final UIInspector inspector = new UIInspector();

    public UIContainerScreen(UIMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.spec      = menu.getSpec();
        this.viewModel = new UIViewModel();
        this.f_97728_ = -10000;
        this.f_97729_ = -10000;
        this.f_97730_ = -10000;
        this.f_97731_ = -10000;

        if (spec.getRoot() instanceof AbstractComponent ac) {
            Size pref = ac.getPreferredSize();
            if (pref.isFixedWidth())  this.f_97726_  = pref.width();
            if (pref.isFixedHeight()) this.f_97727_ = pref.height();
        }
    }

    @Override
    protected void m_7856_() {
        super.m_7856_();
        this.renderer     = new UIRenderer(spec, viewModel);
        this.inputHandler = new InputHandler(spec, viewModel, this::sendAction);
        inputHandler.setScreenSize(f_96543_, f_96544_);
        renderer.init(f_97735_, f_97736_, f_97726_, f_97727_);
    }

    @Override
    protected void m_7286_(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        renderer.renderBackground(graphics, mouseX, mouseY);
    }

    @Override
    public void m_88315_(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.m_88315_(graphics, mouseX, mouseY, partialTick);
        renderer.renderForeground(graphics, mouseX, mouseY);
        m_280072_(graphics, mouseX, mouseY);

        PopupRenderer.render(graphics, f_96543_, f_96544_, mouseX, mouseY);

        ModalManager.render(graphics, f_96543_, f_96544_, mouseX, mouseY);

        if (UIDebugOverlay.isEnabled()) {
            UIDebugOverlay.render(graphics, spec.getRoot());
            inspector.render(graphics, spec, viewModel, mouseX, mouseY, f_96544_);
        }
    }

    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        if (ModalManager.onKeyPressed(keyCode, scanCode, modifiers)) return true;
        if (keyCode == GLFW.GLFW_KEY_U && (modifiers & GLFW.GLFW_MOD_CONTROL) != 0) {
            UIDebugOverlay.toggle();
            return true;
        }
        if (inputHandler.onKeyPressed(keyCode, scanCode, modifiers)) return true;
        return super.m_7933_(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean m_6375_(double mouseX, double mouseY, int button) {
        if (ModalManager.onMouseClicked(mouseX, mouseY, button)) return true;
        if (inputHandler.onMouseClicked(mouseX, mouseY, button)) return true;
        return super.m_6375_(mouseX, mouseY, button);
    }

    @Override
    public boolean m_7979_(double mouseX, double mouseY, int button, double dx, double dy) {
        if (ModalManager.hasModal()) return true;
        if (inputHandler.onMouseDragged(mouseX, mouseY, button, dx, dy)) return true;
        return super.m_7979_(mouseX, mouseY, button, dx, dy);
    }

    @Override
    public boolean m_6348_(double mouseX, double mouseY, int button) {
        if (ModalManager.hasModal()) return true;
        if (inputHandler.onMouseReleased(mouseX, mouseY, button)) return true;
        return super.m_6348_(mouseX, mouseY, button);
    }

    @Override
    public boolean m_6050_(double mouseX, double mouseY, double delta) {
        if (ModalManager.hasModal()) return true;
        if (PopupManager.hasPopup()) { PopupManager.close(); return true; }
        if (inputHandler.onMouseScrolled(mouseX, mouseY, delta)) return true;
        return super.m_6050_(mouseX, mouseY, delta);
    }

    @Override
    public boolean m_5534_(char c, int modifiers) {
        if (ModalManager.onCharTyped(c, modifiers)) return true;
        if (inputHandler.onCharTyped(c, modifiers)) return true;
        return super.m_5534_(c, modifiers);
    }

    @Override
    public void m_7379_() {
        FocusManager.clearFocus();
        ModalManager.clear();
        PopupManager.close();
        super.m_7379_();
    }

    public void applySync(String key, Object value) {
        viewModel.put(key, value);
        renderer.onViewModelUpdated(key);
    }

    private void sendAction(String actionId) {
        ForgeScreenActionSender.sendAction(spec.getScreenId(), actionId);
    }
}