package dev.uiweaver.runtime.network;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;

public class ActionPacket {

    public static final String ID = "uiweaver:action";

    private final int sessionId;
    private final String screenId;
    private final String actionId;
    private final CompoundTag payload;

    public ActionPacket(int sessionId, String screenId, String actionId, CompoundTag payload) {
        this.sessionId = sessionId;
        this.screenId  = screenId;
        this.actionId  = actionId;
        this.payload   = payload != null ? payload : new CompoundTag();
    }

    public ActionPacket(int sessionId, String screenId, String actionId) {
        this(sessionId, screenId, actionId, new CompoundTag());
    }

    public static ActionPacket decode(FriendlyByteBuf buf) {
        int sessionId   = buf.readInt();
        String screenId = buf.m_130277_();
        String actionId = buf.m_130277_();
        CompoundTag payload = buf.m_130260_();
        return new ActionPacket(sessionId, screenId, actionId, payload);
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(sessionId);
        buf.m_130070_(screenId);
        buf.m_130070_(actionId);
        buf.m_130079_(payload);
    }

    public int getSessionId()       { return sessionId; }
    public String getScreenId()     { return screenId; }
    public String getActionId()     { return actionId; }
    public CompoundTag getPayload() { return payload; }
}