package dev.uiweaver.runtime.network;

import dev.uiweaver.api.sync.SyncType;
import dev.uiweaver.runtime.sync.SyncEntry;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;

import java.util.ArrayList;
import java.util.List;

public class SyncPacket {

    public static final String ID = "uiweaver:sync";

    private final String screenId;
    private final List<SyncEntry> entries;

    public SyncPacket(String screenId, List<SyncEntry> entries) {
        this.screenId = screenId;
        this.entries  = entries;
    }

    public static SyncPacket decode(FriendlyByteBuf buf) {
        String screenId = buf.m_130277_();
        int count = buf.m_130242_();
        List<SyncEntry> entries = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            String key   = buf.m_130277_();
            SyncType type = buf.m_130066_(SyncType.class);
            Object value = switch (type) {
                case INT         -> buf.readInt();
                case LONG        -> buf.readLong();
                case BOOLEAN     -> buf.readBoolean();
                case FLOAT       -> buf.readFloat();
                case STRING      -> buf.m_130277_();
                case STRING_LIST -> {
                    int len = buf.m_130242_();
                    List<String> list = new ArrayList<>(len);
                    for (int j = 0; j < len; j++) list.add(buf.m_130277_());
                    yield List.copyOf(list);
                }
                case NBT_LIST -> {
                    int len = buf.m_130242_();
                    List<CompoundTag> list = new ArrayList<>(len);
                    for (int j = 0; j < len; j++) list.add(buf.m_130260_());
                    yield List.copyOf(list);
                }
            };
            entries.add(new SyncEntry(key, type, value));
        }
        return new SyncPacket(screenId, entries);
    }

    public void encode(FriendlyByteBuf buf) {
        buf.m_130070_(screenId);
        buf.m_130130_(entries.size());
        for (SyncEntry e : entries) {
            buf.m_130070_(e.key());
            buf.m_130068_(e.type());
            switch (e.type()) {
                case INT     -> buf.writeInt(e.asInt());
                case LONG    -> buf.writeLong(e.asLong());
                case BOOLEAN -> buf.writeBoolean(e.asBoolean());
                case FLOAT   -> buf.writeFloat(e.asFloat());
                case STRING  -> buf.m_130070_(e.asString());
                case STRING_LIST -> {
                    List<String> list = e.asStringList();
                    buf.m_130130_(list.size());
                    list.forEach(buf::m_130070_);
                }
                case NBT_LIST -> {
                    List<CompoundTag> list = e.asNbtList();
                    buf.m_130130_(list.size());
                    list.forEach(buf::m_130079_);
                }
            }
        }
    }

    public String getScreenId()       { return screenId; }
    public List<SyncEntry> getEntries() { return entries; }
}